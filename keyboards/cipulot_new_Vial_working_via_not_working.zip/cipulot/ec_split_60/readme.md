# EC Split 60

![EC Split 60 PCB]()

EC Split 60 layout keyboard.

* Keyboard Maintainer: [cipulot](https://github.com/cipulot)
* Hardware Supported: EC Split 60
* Hardware Availability: [mtnkbd](https://mtnkbd.com/)

Make example for this keyboard (after setting up your build environment):

    make cipulot/ec_split_60/left:default
    make cipulot/ec_split_60/right:default

Flashing example for this keyboard:

    make cipulot/ec_split_60/left:default:flash
    make cipulot/ec_split_60/right:default:flash

See the [build environment setup](https://docs.qmk.fm/#/getting_started_build_tools) and the [make instructions](https://docs.qmk.fm/#/getting_started_make_guide) for more information. Brand new to QMK? Start with our [Complete Newbs Guide](https://docs.qmk.fm/#/newbs).

## Bootloader

Enter the bootloader in 2 ways:

* **Physical reset**: Long press the button on the back of the PCB
* **Keycode in layout**: Press the key mapped to `QK_BOOT` if it is available
