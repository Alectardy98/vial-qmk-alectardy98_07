#include QMK_KEYBOARD_H

enum _layer {
  _BASE,
  _FN
  };

// ---------------- Minimal keymaps (placeholders) ----------------
const uint16_t PROGMEM keymaps[][MATRIX_ROWS][MATRIX_COLS] = {
    [_BASE] = LAYOUT(
         KC_ESC, _______,   KC_F1,   KC_F2, _______, _______, _______, _______, _______, _______, _______, _______, _______, _______, _______, _______, _______, _______, _______,      KC_INS, KC_HOME, KC_PGUP, _______,
        _______, _______,   KC_F3,   KC_F4,  KC_GRV,    KC_1,    KC_2,    KC_3,    KC_4,    KC_5,    KC_6,    KC_7,    KC_8,    KC_9,    KC_0, KC_MINS,  KC_EQL, _______, KC_BSPC,      KC_DEL,  KC_END, KC_PGDN, _______,
        _______, _______,   KC_F5,   KC_F6,  KC_TAB,    KC_Q,    KC_W,    KC_E,    KC_R,    KC_T,    KC_Y,    KC_U,    KC_I,    KC_O,    KC_P, KC_LBRC, KC_RBRC, KC_BSLS,                         KC_UP,
        _______, _______,   KC_F7,   KC_F8, KC_CAPS,    KC_A,    KC_S,    KC_D,    KC_F,    KC_G,    KC_H,    KC_J,    KC_K,    KC_L, KC_SCLN, KC_QUOT,  KC_ENT,  KC_ENT,              KC_LEFT, KC_DOWN, KC_RGHT,
        _______, _______,   KC_F9,  KC_F10, KC_LSFT,    KC_Z,    KC_X,    KC_C,    KC_V,    KC_B,    KC_N,    KC_M, KC_COMM,  KC_DOT, KC_SLSH, KC_RSFT, MO(_FN),                                KC_DOWN,
        _______, _______,  KC_F11,  KC_F12,          MO(_FN),                                     KC_SPC,                                      KC_RALT,                                _______, _______, _______
    ),
    [_FN] = LAYOUT(
        _______, _______, _______, _______, _______, _______, _______, _______, _______, _______, _______, _______, _______, _______, _______, _______, _______, _______, _______,     _______, _______, _______, _______,
        _______, _______, _______, _______, _______, _______, _______, _______, _______, _______, _______, _______, _______, _______, _______, _______, _______, _______, _______,     _______, _______, _______, _______,
        _______, _______, _______, _______, _______, _______, _______, _______, _______, _______, _______, _______, _______, _______, _______, _______, _______, _______,                       _______,
        _______, _______, _______, _______, _______, _______, _______, _______, _______, _______, _______, _______, _______, _______, _______, _______, _______, _______,              _______, _______, _______,
        _______, _______, _______, _______, _______, _______, _______, _______, _______, _______, _______, _______, _______, _______, _______, _______, _______,                                _______,
        _______, _______, _______, _______,          _______,                                     _______,                                     _______,                                _______, _______, _______
    ),
};

#ifdef RGB_MATRIX_ENABLE
// ---------------- RGB Matrix "Section Mode" (Vial-friendly) ----------------
// When section_mode == false: do nothing (VialRGB / QMK effects control LEDs normally).
// When section_mode == true : firmware takes over and paints only the enabled sections.

//#define ARRAY_SIZE(a) (sizeof(a) / sizeof((a)[0]))

static const uint8_t LEDS_QB_LOGO[]    = { 0, 1, 2 };
static const uint8_t LEDS_SCREEN[]     = { 3, 4, 5 };
static const uint8_t LEDS_CH_A[]       = { 6, 7, 8, 9, 10, 11, 12, 13 };
static const uint8_t LEDS_CH_B[]       = { 14, 15, 16, 17, 18, 19, 20, 21 };
static const uint8_t LEDS_AB_MIX[]     = { 22, 23, 24 };
static const uint8_t LEDS_AB_PREVIEW[] = { 25, 26, 27, 28, 29 };

// Keyboard numbers: 30=5,31=3,32=1,33=2,34=4,35=6
static const uint8_t LED_KBD_1[] = { 32 };
static const uint8_t LED_KBD_2[] = { 33 };
static const uint8_t LED_KBD_3[] = { 31 };
static const uint8_t LED_KBD_4[] = { 34 };
static const uint8_t LED_KBD_5[] = { 30 };
static const uint8_t LED_KBD_6[] = { 35 };

// Channel A numbers: 36=5,37=3,38=1,39=2,40=4,41=6
static const uint8_t LED_A_1[] = { 38 };
static const uint8_t LED_A_2[] = { 39 };
static const uint8_t LED_A_3[] = { 37 };
static const uint8_t LED_A_4[] = { 40 };
static const uint8_t LED_A_5[] = { 36 };
static const uint8_t LED_A_6[] = { 41 };

// Channel B numbers: 42=5,43=3,44=1,45=2,46=4,47=6
static const uint8_t LED_B_1[] = { 44 };
static const uint8_t LED_B_2[] = { 45 };
static const uint8_t LED_B_3[] = { 43 };
static const uint8_t LED_B_4[] = { 46 };
static const uint8_t LED_B_5[] = { 42 };
static const uint8_t LED_B_6[] = { 47 };

typedef struct {
    const uint8_t *idx;
    uint8_t        len;
} led_section_t;

enum {
    SEC_QB_LOGO,
    SEC_SCREEN,
    SEC_CH_A,
    SEC_CH_B,
    SEC_AB_MIX,
    SEC_AB_PREVIEW,

    SEC_KBD_1, SEC_KBD_2, SEC_KBD_3, SEC_KBD_4, SEC_KBD_5, SEC_KBD_6,
    SEC_A_1,   SEC_A_2,   SEC_A_3,   SEC_A_4,   SEC_A_5,   SEC_A_6,
    SEC_B_1,   SEC_B_2,   SEC_B_3,   SEC_B_4,   SEC_B_5,   SEC_B_6,

    SEC_COUNT
};

static const led_section_t g_sections[SEC_COUNT] = {
    [SEC_QB_LOGO]    = { LEDS_QB_LOGO,    ARRAY_SIZE(LEDS_QB_LOGO)    },
    [SEC_SCREEN]     = { LEDS_SCREEN,     ARRAY_SIZE(LEDS_SCREEN)     },
    [SEC_CH_A]       = { LEDS_CH_A,       ARRAY_SIZE(LEDS_CH_A)       },
    [SEC_CH_B]       = { LEDS_CH_B,       ARRAY_SIZE(LEDS_CH_B)       },
    [SEC_AB_MIX]     = { LEDS_AB_MIX,     ARRAY_SIZE(LEDS_AB_MIX)     },
    [SEC_AB_PREVIEW] = { LEDS_AB_PREVIEW, ARRAY_SIZE(LEDS_AB_PREVIEW) },

    [SEC_KBD_1] = { LED_KBD_1, ARRAY_SIZE(LED_KBD_1) },
    [SEC_KBD_2] = { LED_KBD_2, ARRAY_SIZE(LED_KBD_2) },
    [SEC_KBD_3] = { LED_KBD_3, ARRAY_SIZE(LED_KBD_3) },
    [SEC_KBD_4] = { LED_KBD_4, ARRAY_SIZE(LED_KBD_4) },
    [SEC_KBD_5] = { LED_KBD_5, ARRAY_SIZE(LED_KBD_5) },
    [SEC_KBD_6] = { LED_KBD_6, ARRAY_SIZE(LED_KBD_6) },

    [SEC_A_1] = { LED_A_1, ARRAY_SIZE(LED_A_1) },
    [SEC_A_2] = { LED_A_2, ARRAY_SIZE(LED_A_2) },
    [SEC_A_3] = { LED_A_3, ARRAY_SIZE(LED_A_3) },
    [SEC_A_4] = { LED_A_4, ARRAY_SIZE(LED_A_4) },
    [SEC_A_5] = { LED_A_5, ARRAY_SIZE(LED_A_5) },
    [SEC_A_6] = { LED_A_6, ARRAY_SIZE(LED_A_6) },

    [SEC_B_1] = { LED_B_1, ARRAY_SIZE(LED_B_1) },
    [SEC_B_2] = { LED_B_2, ARRAY_SIZE(LED_B_2) },
    [SEC_B_3] = { LED_B_3, ARRAY_SIZE(LED_B_3) },
    [SEC_B_4] = { LED_B_4, ARRAY_SIZE(LED_B_4) },
    [SEC_B_5] = { LED_B_5, ARRAY_SIZE(LED_B_5) },
    [SEC_B_6] = { LED_B_6, ARRAY_SIZE(LED_B_6) },
};

static bool     section_mode = false;
static uint32_t section_mask = 0;

static inline void toggle_section(uint8_t sec) {
    section_mask ^= (1u << sec);
}

enum custom_keycodes {
    KB_SEC_MODE = QK_KB_0,
    KB_CLR_SECS,

    KB_TOG_LOGO,
    KB_TOG_SCREEN,
    KB_TOG_CH_A,
    KB_TOG_CH_B,
    KB_TOG_AB_MIX,
    KB_TOG_AB_PREV,

    KB_TOG_KBD_1, KB_TOG_KBD_2, KB_TOG_KBD_3, KB_TOG_KBD_4, KB_TOG_KBD_5, KB_TOG_KBD_6,

    KB_TOG_A_1, KB_TOG_A_2, KB_TOG_A_3, KB_TOG_A_4, KB_TOG_A_5, KB_TOG_A_6,

    KB_TOG_B_1, KB_TOG_B_2, KB_TOG_B_3, KB_TOG_B_4, KB_TOG_B_5, KB_TOG_B_6,
};

bool process_record_user(uint16_t keycode, keyrecord_t *record) {
    if (!record->event.pressed) return true;

    switch (keycode) {
        case KB_SEC_MODE:
            section_mode = !section_mode;
            if (section_mode) {
                rgb_matrix_enable_noeeprom();
            }
            return false;

        case KB_CLR_SECS:
            section_mask = 0;
            return false;

        case KB_TOG_LOGO:    toggle_section(SEC_QB_LOGO);    return false;
        case KB_TOG_SCREEN:  toggle_section(SEC_SCREEN);     return false;
        case KB_TOG_CH_A:    toggle_section(SEC_CH_A);       return false;
        case KB_TOG_CH_B:    toggle_section(SEC_CH_B);       return false;
        case KB_TOG_AB_MIX:  toggle_section(SEC_AB_MIX);     return false;
        case KB_TOG_AB_PREV: toggle_section(SEC_AB_PREVIEW); return false;

        case KB_TOG_KBD_1: toggle_section(SEC_KBD_1); return false;
        case KB_TOG_KBD_2: toggle_section(SEC_KBD_2); return false;
        case KB_TOG_KBD_3: toggle_section(SEC_KBD_3); return false;
        case KB_TOG_KBD_4: toggle_section(SEC_KBD_4); return false;
        case KB_TOG_KBD_5: toggle_section(SEC_KBD_5); return false;
        case KB_TOG_KBD_6: toggle_section(SEC_KBD_6); return false;

        case KB_TOG_A_1: toggle_section(SEC_A_1); return false;
        case KB_TOG_A_2: toggle_section(SEC_A_2); return false;
        case KB_TOG_A_3: toggle_section(SEC_A_3); return false;
        case KB_TOG_A_4: toggle_section(SEC_A_4); return false;
        case KB_TOG_A_5: toggle_section(SEC_A_5); return false;
        case KB_TOG_A_6: toggle_section(SEC_A_6); return false;

        case KB_TOG_B_1: toggle_section(SEC_B_1); return false;
        case KB_TOG_B_2: toggle_section(SEC_B_2); return false;
        case KB_TOG_B_3: toggle_section(SEC_B_3); return false;
        case KB_TOG_B_4: toggle_section(SEC_B_4); return false;
        case KB_TOG_B_5: toggle_section(SEC_B_5); return false;
        case KB_TOG_B_6: toggle_section(SEC_B_6); return false;
    }
    return true;
}

static void paint_section(uint8_t sec, uint8_t led_min, uint8_t led_max, uint8_t r, uint8_t g, uint8_t b) {
    if (!(section_mask & (1u << sec))) return;

    const led_section_t s = g_sections[sec];
    for (uint8_t i = 0; i < s.len; i++) {
        uint8_t idx = s.idx[i];
        if (idx >= led_min && idx < led_max) {
            rgb_matrix_set_color(idx, r, g, b);
        }
    }
}

bool rgb_matrix_indicators_advanced_user(uint8_t led_min, uint8_t led_max) {
    if (!section_mode) return true;

    for (uint8_t i = led_min; i < led_max; i++) {
        rgb_matrix_set_color(i, 0, 0, 0);
    }

    paint_section(SEC_QB_LOGO,    led_min, led_max, 255,   0,   0);
    paint_section(SEC_SCREEN,     led_min, led_max,   0, 255,   0);
    paint_section(SEC_CH_A,       led_min, led_max,   0,   0, 255);
    paint_section(SEC_CH_B,       led_min, led_max, 255, 255,   0);
    paint_section(SEC_AB_MIX,     led_min, led_max, 255,   0, 255);
    paint_section(SEC_AB_PREVIEW, led_min, led_max,   0, 255, 255);

    paint_section(SEC_KBD_1, led_min, led_max, 255,255,255);
    paint_section(SEC_KBD_2, led_min, led_max, 255,255,255);
    paint_section(SEC_KBD_3, led_min, led_max, 255,255,255);
    paint_section(SEC_KBD_4, led_min, led_max, 255,255,255);
    paint_section(SEC_KBD_5, led_min, led_max, 255,255,255);
    paint_section(SEC_KBD_6, led_min, led_max, 255,255,255);

    paint_section(SEC_A_1, led_min, led_max,   0,  80, 255);
    paint_section(SEC_A_2, led_min, led_max,   0,  80, 255);
    paint_section(SEC_A_3, led_min, led_max,   0,  80, 255);
    paint_section(SEC_A_4, led_min, led_max,   0,  80, 255);
    paint_section(SEC_A_5, led_min, led_max,   0,  80, 255);
    paint_section(SEC_A_6, led_min, led_max,   0,  80, 255);

    paint_section(SEC_B_1, led_min, led_max, 255, 200,   0);
    paint_section(SEC_B_2, led_min, led_max, 255, 200,   0);
    paint_section(SEC_B_3, led_min, led_max, 255, 200,   0);
    paint_section(SEC_B_4, led_min, led_max, 255, 200,   0);
    paint_section(SEC_B_5, led_min, led_max, 255, 200,   0);
    paint_section(SEC_B_6, led_min, led_max, 255, 200,   0);

    return false;
}

#endif // RGB_MATRIX_ENABLE
