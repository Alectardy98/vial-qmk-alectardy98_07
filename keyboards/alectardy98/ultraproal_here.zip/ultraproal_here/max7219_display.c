#include "quantum.h"
#include "max7219_display.h"
#include "max7219.pio.h"
#include "hardware/pio.h"
#include "hardware/clocks.h"

#define MAX7219_PIO        pio0
#define MAX7219_SM         0
#define MAX7219_CLK_PIN    8
#define MAX7219_DIN_PIN    7
#define MAX7219_LOAD_PIN   6

void max7219_spi_program_init(PIO pio, uint sm, uint offset, uint din_pin, uint clk_pin) {
    pio_sm_config c = max7219_spi_program_get_default_config(offset);

    sm_config_set_out_shift(&c, true, true, 16); // MSB-first, auto-pull
    sm_config_set_out_pins(&c, din_pin, 1);
    sm_config_set_sideset_pins(&c, clk_pin);
    sm_config_set_fifo_join(&c, PIO_FIFO_JOIN_TX);

    pio_gpio_init(pio, din_pin);
    pio_gpio_init(pio, clk_pin);
    pio_sm_set_consecutive_pindirs(pio, sm, din_pin, 1, true);
    pio_sm_set_consecutive_pindirs(pio, sm, clk_pin, 1, true);

    sm_config_set_clkdiv(&c, 1.0f);
    pio_sm_init(pio, sm, offset, &c);
    pio_sm_set_enabled(pio, sm, true);
}

void max7219_pio_init(void) {
    uint offset = pio_add_program(MAX7219_PIO, &max7219_spi_program);
    max7219_spi_program_init(MAX7219_PIO, MAX7219_SM, offset, MAX7219_DIN_PIN, MAX7219_CLK_PIN);

    gpio_init(MAX7219_LOAD_PIN);
    gpio_set_dir(MAX7219_LOAD_PIN, GPIO_OUT);
    gpio_put(MAX7219_LOAD_PIN, 1);
}

void max7219_send(uint8_t reg, uint8_t value) {
    uint16_t word = ((reg & 0xFF) << 8) | (value & 0xFF);
    gpio_put(MAX7219_LOAD_PIN, 0);
    pio_sm_put_blocking(MAX7219_PIO, MAX7219_SM, word);
    while (!pio_sm_is_tx_fifo_empty(MAX7219_PIO, MAX7219_SM)) tight_loop_contents();
    sleep_us(1);
    gpio_put(MAX7219_LOAD_PIN, 1);
}