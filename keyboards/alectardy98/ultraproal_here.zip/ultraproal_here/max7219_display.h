#pragma once
#include <stdint.h>

void max7219_pio_init(void);
void max7219_send(uint8_t reg, uint8_t value);