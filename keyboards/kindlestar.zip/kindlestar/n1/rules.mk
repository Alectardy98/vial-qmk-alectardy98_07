
 MCU        = STM32F103
 BOOTLOADER = stm32duino
