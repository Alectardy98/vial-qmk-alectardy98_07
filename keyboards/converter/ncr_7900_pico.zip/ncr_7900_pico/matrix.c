#include "quantum.h"
#include "print.h"     // for xprintf()
#include "hardware/uart.h"
#include "hardware/gpio.h"
#include "config.h"     // SERIAL_UART_BAUD, IDLE_CODE, MATRIX_ROWS

// — scan→pos map (fill with your final values; 0xFF = ignore) —
static const uint8_t sc_to_pos[256] = {
    [0x63] = 0x00,
    [0x33] = 0x10,
    [0x66] = 0x01,
    [0x19] = 0x11,
    // ... continue mapping your codes ...
};

static matrix_row_t matrix[MATRIX_ROWS];
static uint8_t      last_sc = 0xFF;

// Configure UART1 with hardware RX inversion on RP2040
static void uart_board_init(void) {
    // Initialize UART1 at SERIAL_UART_BAUD
    uart_init(uart1, SERIAL_UART_BAUD);
    // Configure RX pin for UART function
    gpio_set_function(PICO_DEFAULT_UART_RX_PIN, GPIO_FUNC_UART);
    // Disable hardware flow control
    uart_set_hw_flow(uart1, false, false);
    // Enable RX inversion
    uart_get_hw(uart1)->cr |= UART_UARTCR_RXINV_BITS;
}

void matrix_init(void) {
    uart_board_init();
    for (uint8_t r = 0; r < MATRIX_ROWS; r++) {
        matrix[r] = 0;
    }
    last_sc = 0xFF;
}

uint8_t matrix_scan(void) {
    // Heartbeat detection state
    static bool     hb_first = false;
    static uint32_t hb_count = 0;

    while (uart_is_readable(uart1)) {
        // 1) Read inverted data directly
        uint8_t raw = uart_getc(uart1);

        // 2) Heartbeat: detect real FF then IDLE_CODE sequence
        if (!hb_first) {
            if (raw == 0xFF) {
                hb_first = true;
                continue;
            }
        } else {
            if (raw == IDLE_CODE) {
                hb_first = false;
                hb_count++;
                // Optional heartbeat log:
                // xprintf("Heartbeat #%u\n", hb_count);
                continue;
            } else {
                hb_first = false;
            }
        }

        // 3) Log raw and scan code for hid_listen
        xprintf("RAW:%02X SC:%02X ", raw, raw);

        // 4) Map scan code to matrix position
        uint8_t pos = sc_to_pos[raw];
        if (pos == 0xFF) {
            xprintf("→IGNORE\n");
            continue;
        }

        // 5) Compute row and column
        uint8_t row = pos >> 4;
        uint8_t col = pos & 0x0F;

        // 6) Release previous key if different
        if (last_sc != 0xFF && last_sc != raw) {
            uint8_t old = sc_to_pos[last_sc];
            matrix[old >> 4] &= ~(1u << (old & 0x0F));
        }

        // 7) Press new key
        matrix[row] |= (1u << col);
        last_sc = raw;

        xprintf("→MAKE row%u,col%u\n", row, col);
    }
    return 0;
}

matrix_row_t matrix_get_row(uint8_t row) {
    return matrix[row];
}

void matrix_print(void) { }
