CUSTOM_MATRIX = yes
SRC = matrix.c
SERIAL_DRIVER = vendor

