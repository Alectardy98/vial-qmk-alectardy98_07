#define VIAL_KEYBOARD_UID {0xD8, 0xFA, 0x1B, 0xE3, 0x84, 0x41, 0x9F, 0x78}
#define VIA_EEPROM_LAYOUT_OPTIONS_SIZE 4

#define DYNAMIC_KEYMAP_LAYER_COUNT 3
#define VIAL_TAP_DANCE_ENTRIES 4
#define VIAL_COMBO_ENTRIES 4
#define VIAL_KEY_OVERRIDE_ENTRIES 4

#define ONESHOT_TAP_TOGGLE 2   // tap twice to lock until tapped again
#define ONESHOT_TIMEOUT    20000  // ms before auto‑release
